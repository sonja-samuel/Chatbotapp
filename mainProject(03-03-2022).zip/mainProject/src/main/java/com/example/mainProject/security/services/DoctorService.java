package com.example.mainProject.security.services;

import com.example.mainProject.dto.DoctorDto;

public interface DoctorService {
	
	public void addDetails(DoctorDto doctordto);

}
