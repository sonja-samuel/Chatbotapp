package com.example.mainProject.security.services;

public interface ChatService {
	
	public  void initiateBot();

}
