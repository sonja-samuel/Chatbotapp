package com.mentbot.mainProject.chat;

public class Welcome {
	private String content;

	public Welcome() {
	}

	public String getContent() {
		return content;
	}

	public Welcome(String content) {
		
		this.content = content;
	}

	

}
