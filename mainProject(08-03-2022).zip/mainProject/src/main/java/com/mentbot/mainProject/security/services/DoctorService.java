package com.mentbot.mainProject.security.services;

import com.mentbot.mainProject.dto.DoctorDto;

public interface DoctorService {
	
	public void addDetails(DoctorDto doctordto);

}
