package com.mentbot.mainProject.models;

public enum ERole {
     
     ROLE_DOCTOR,
     ROLE_ADMIN,
     ROLE_PATIENT
}
