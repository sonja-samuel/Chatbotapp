package com.mentbot.mainProject.security.services;

public interface ChatService {
	
	public  void initiateBot();

}
